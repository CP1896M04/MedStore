/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.threadgroupclass;

/**
 *
 * @author theanh
 */
public class ThreadExample1 extends Thread
{    
    String name;
    ThreadExample1(String threadname,ThreadGroup tgop)
    {
        super(tgop, threadname);
        this.name = threadname;
        start();
    }
            
    public void run()
    {
        for(int i=0;i<1000;i++)
        {
            try
            {
                Thread.sleep(1);
                //System.out.println(name+" is running...");
            }
            catch(InterruptedException e)
            {
                System.out.println("Exception encountered");
            }
        }
        System.out.println(Thread.currentThread().getName() +  " finished executing"); 
    }
}
