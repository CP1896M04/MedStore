/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.threadgroupclass;

/**
 *
 * @author theanh
 */
public class TestThreadEx1 
{
    public static void main(String[] args) throws InterruptedException, SecurityException 
    {
        ThreadGroup gfg = new ThreadGroup("parent thread group"); 
        ThreadGroup gfg_child = new ThreadGroup(gfg,"child thread group"); 
        
        ThreadExample1 dog = new ThreadExample1("Dog", gfg);         
        System.out.println("Dog is starting run"); 
        
        ThreadExample1 cat = new ThreadExample1("Cat", gfg); 
        System.out.println("Cat  is starting run"); 
        
        // checking the number of active thread 
        System.out.println("number of active thread: " + gfg.activeCount()+", "+gfg.activeGroupCount()); 
        
        //final void checkAccess()=> access and change group of thread
        gfg.checkAccess();
        System.out.println(gfg.getName()+" has access");
        
        dog.checkAccess();
        System.out.println(dog.getName()+" has access");
        
        cat.checkAccess();
        System.out.println(cat.getName()+" has access");
        
        //// returns the number of threads put into the array 
        Thread[] group = new Thread[gfg.activeCount()];
        int count = gfg.enumerate(group); 
        System.out.println("count: "+count);
        for (int i = 0; i < count; i++)  
        { 
            System.out.println("Thread " + group[i].getName() + " found"); 
        } 
        //assert (dog.isInterrupted() == true) : "Group is not destroyed yet"; 
            
               if (gfg.isDestroyed() == true) 
            System.out.println("Group is destroyed"); 
        else
            System.out.println("Group is not destroyed"); 
               
        System.out.println("number of active thread before join(): " + gfg.activeCount());        
        dog.join();
        cat.join(); 
        gfg.destroy();
        
        if(gfg.isDestroyed())
            System.out.println("Group is destroyed"); 
        else
            System.out.println("Group is not destroyed"); 
               
        //assert (dog.isInterrupted() == true) : "Group is destroyed"; 
        //dog.destroy();
        //System.out.println(dog.getName() + " destroyed");         
        System.out.println("number of active thread after join(): " + gfg.activeCount());
        
        
    }
}
