/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.regex;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author theanh
 */
public class RegexExample3 
{
    public static void main(String args[])
    {  
        //System.out.println("Input a string: ");
        //Scanner input = new Scanner(System.in);
        //String in = input.nextLine()
        System.out.println(Pattern.matches("[afmn]", "am"));// (not a or m or n)  
        System.out.println(Pattern.matches("[^ahmn]", "h"));// (among a or m or n)  
        System.out.println(Pattern.matches("[amyn]", "ammmna"));// (m and a comes more than once)  
    }
}
