/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.regex;

import java.util.regex.Pattern;

/**
 *
 * @author theanh
 */
public class RegexExample2 
{
    public static void main(String args[])
    {
        //The . (dot) represents a single character.
        System.out.println(Pattern.matches(".s", "as"));
        System.out.println(Pattern.matches(".s", "mk"));
        System.out.println(Pattern.matches(".s", "mst"));  
        System.out.println(Pattern.matches(".s", "amms"));//)  
        System.out.println(Pattern.matches("..s", "mas"));//s)  
    }
}
