/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.regex;

import java.util.regex.Pattern;

/**
 *
 * @author theanh
 */
public class RegexExample7 
{
    public static void main(String args[])
    {  
        System.out.println("by character classes and quantifiers ...");  
        System.out.println(Pattern.matches("[0]{1}[1-9]{1}[0-9]{8}", "0153038949"));//true 
        
        System.out.println(Pattern.matches("[789][0-9]{9}", "9953038949"));//true  

        System.out.println(Pattern.matches("[789][0-9]{9}", "99530389490"));//false (11 characters)  
        System.out.println(Pattern.matches("[789][0-9]{9}", "6953038949"));//false (starts from 6)  
        System.out.println(Pattern.matches("[789][0-9]{9}", "8853038949"));//true  

        System.out.println("by metacharacters ...");  
        System.out.println(Pattern.matches("[789]{1}\\d{9}", "8853038949"));//true  
        System.out.println(Pattern.matches("[789]{1}\\d{9}", "3853038949"));//false (starts from 3)  
        System.out.println(Pattern.matches("[0]{1}[1-9]{1}[\\S]{8}", "09jg4*&%5n"));//true  
        //Check date
        System.out.println(Pattern.matches("(0?[1-9]|[12][0-9]|[3][01])/(0?[1-9]|1[0-2])/((19|20)[0-9]{2})","23/12/2018"));
        //Check Email
        System.out.println(Pattern.matches("([a-z._%+-]{3,50})@([a-z.-]{2,}).([a-z]{2,6})","..aac.%+-_@gmail.com.vn"));
        
        System.out.println("ketqua: "+Pattern.matches("(D|C)\\d{2}(CN|DT|CK)\\d{1,3}","D14CK23356"));
        
        //Check Password
        //System.out.println(Pattern.matches("([a-z._%+-]{3,50})@([a-z.-]{2,}).([a-z]{2,6})","tanh%._gfk@g-ma-il.com.vn"));
    }    
}
