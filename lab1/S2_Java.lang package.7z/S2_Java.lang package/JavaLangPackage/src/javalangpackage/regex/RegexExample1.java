/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author theanh
 */
public class RegexExample1 
{
    public static void main(String args[]){  
        //1st way  
        Pattern p = Pattern.compile(".s");//. represents single character  //tao pattern
        Matcher m = p.matcher("bs");  //dua chuoi moi vao de so sanh voi mau p
        boolean b = m.matches();  //tra ve ket qua co hop khong

        //2nd way  
        boolean b2=Pattern.compile(".s").matcher("as").matches();  

        //3rd way  
        boolean b3 = Pattern.matches(".s", "as");  

        System.out.println(b+" "+b2+" "+b3);  
    }  
}
