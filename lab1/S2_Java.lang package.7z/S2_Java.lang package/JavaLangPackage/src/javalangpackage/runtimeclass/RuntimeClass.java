/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.runtimeclass;

/**
 *
 * @author theanh
 */
public class RuntimeClass 
{
    public static void main(String[] args) 
    { 
        // get the current runtime assosiated with this process 
        Runtime run = Runtime.getRuntime(); 
        // print the current free memory for this runtime 
        System.out.println("Free memory amount: " + run.freeMemory()); 
        
        // print the number of free bytes 
        System.out.println("Free memory amount on run time:" + Runtime.getRuntime().freeMemory()); 
        
        // print the number of total bytes 
        System.out.println("Total memory amount: " + Runtime.getRuntime().totalMemory()); 
        
        try
        {          
            // create a process and execute google-chrome 
            Process process = Runtime.getRuntime().exec("C:\\Program Files\\CCleaner\\CCleaner64.exe"); 
            System.out.println("Google Chrome successfully started"); 
        }catch (Exception e) 
        { 
            e.printStackTrace(); 
        } 
        
        
    } 
}
