/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.objectclass;

/**
 *
 * @author theanh
 */
public class TestObjectClass 
{
    public static void main(String[] args) 
    {
        ObjectClass oc1 = new ObjectClass(1234,"bob");
        ObjectClass oc2 = new ObjectClass(1236,"bob");
        
        //oc1.getStringForm();
        
        oc2=oc1;
        
        if(oc1==oc2)
        {            
            System.out.println("33 Object 2 now is equal object 1");
        }
        else System.out.println("33 Object 2 now is not equal object 1");
//        
        if(oc1.equals(oc2))
        {
            System.out.println("Object 2 is equal object 1");
        }
        else System.out.println("Object 2 is not equal object 1");
//        
//        //oc2=oc1;
//        
//        if(oc1.equals(oc2))
//        {            
//            System.out.println("Object 2 now is equal object 1");
//        }
//        else System.out.println("Object 2 now is not equal object 1");
//        
//        
//
//        System.out.println(oc1.toString());
//        System.out.println(oc2.toString());
        
//        ObjectClass a1 = new ObjectClass(1234,"Robby");
//	ObjectClass a2 = new ObjectClass(1233,"Robby");
//
//	    System.out.println(a1.equals(a2)); //true
//            System.out.println(a1==a2); //true
    }
}
