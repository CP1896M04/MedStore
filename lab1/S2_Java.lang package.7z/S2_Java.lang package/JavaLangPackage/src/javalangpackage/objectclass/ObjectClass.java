/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.objectclass;

/**
 *
 * @author theanh
 */
public class ObjectClass {
    String name;
    Integer num;
    public ObjectClass(){}
    
    public ObjectClass(Integer num, String name)
    {
        this.name = name;
        this.num = num;
    }
    
    //method to use the toString() method;
    public void getStringForm()
    {
        System.out.println("String form of num is: "+num.toString());
    }
    
    @Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ObjectClass other = (ObjectClass) obj;
	if (name == null) {
		if (other.name != null)
			return false;
	} else if (!name.equals(other.name))
		return false;
	return true;
}
}

