/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.systemclass;

/**
 *
 * @author theanh
 */
public class SystemClass 
{
    int arr1[]={1,2,3,4};
    int arr2[]={6,7,8,0,0,0,0,0,0,0,0,0};

    public void getTime()
    {
        System.out.println("Current Time in milliseconds: "+System.currentTimeMillis());
    }
    
    public void copyArray()
    {
        System.arraycopy(arr1, 0, arr2, 3, 3);
        for(int i=0;i<arr2.length;i++)
            System.out.println(arr2[i]);
    }    
    
    public void getProper()
    {
        System.out.println("Properties: "+System.getProperties());   
    }
    
    public void getPath(String variable)
    {
        System.out.println("Value of path variable is: "+System.getenv(variable));
    }
    
}
