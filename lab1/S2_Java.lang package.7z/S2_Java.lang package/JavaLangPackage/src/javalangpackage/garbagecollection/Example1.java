/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.garbagecollection;

/**
 * example of automatic garbage collection
 * @author theanh
 */
public class Example1 {
    int num1;
    int num2;
    
    public void setNum(int num1, int num2)
    {
        this.num1 = num1;
        this.num2 = num2;
    }
    public void showNum()
    {
        System.out.println("Value of num1: "+this.num1);
        System.out.println("Value of num2: "+this.num2);
    }
    public static void main(String[] args) 
    {
        Example1 ex = new Example1();
        Example1 ex2 = new Example1();
        ex.setNum(2,3);
        ex2.setNum(4, 5);
        ex.showNum();
        ex2.showNum();
    }
}
