/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.math;

/**
 *
 * @author theanh
 */
public class Maths {
    int num1;
    int num2;
    
    public Maths()
    {        
    }
    
    public Maths(int num1, int num2)
    {        
        this.num1 = num1;
        this.num2 = num2;
    }
    
    public void doMax()
    {
        System.out.println("Maximun is: "+Math.max(num1, num2));
    }
    
    public void doMin()
    {
        System.out.println("Minimun is: "+Math.min(num1, num2));
    }
    
    public void doPow()
    {
        System.out.println("Result of Power is: "+Math.pow(num1, num1));
    }
    
    public void getRandom()
    {
        System.out.println("Random is: "+Math.random()*10);
    }
    
    public void doSquareRoot()
    {
        System.out.println("Sqare root of num1 is: "+Math.sqrt(num1));
    }
}
