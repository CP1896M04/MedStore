/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.math;

/**
 *
 * @author theanh
 */
public class TestMath 
{
    public static void main(String[] args) 
    {
        double var = 15.345678;
        System.out.println("Ceil of var is: "+Math.ceil(var));
        System.out.println("Floor of var is: "+Math.floor(var));
        System.out.println("Absolute value of var is: "+Math.abs(-var));
        
        System.out.println("Epsilon= "+Math.E);
        System.out.println("Exp of var is: "+Math.exp(var)); //e^var
        System.out.println("Epsilon power= "+Math.pow(Math.E,var));
        
        System.out.println("Exp of var is: "+(double)var*var);
        System.out.println("Log of var is: "+Math.log(var));
        
         Maths mt = new  Maths(2,4);
         mt.doMax();
         mt.doMin();
         mt.doPow();
         mt.doSquareRoot();
         mt.getRandom();
    }
}
