/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangpackage.classclass;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

/**
 *
 * @author theanh
 */
public class TestClass {

    public String a;
    public int b;
    public float c;

    public void add(int a, int b) {

    }

    public int sub() {
        return 1;
    }

    public static void main(String[] args) throws ClassNotFoundException, IOException {
        // returns the Class object for the class with the specified name  
        Class c1 = Class.forName("javalangpackage.classclass.TestClass");
        //Class c2 = int.class; 
        //Class c3 = void.class; 

//        Field[] field = c1.getFields();
//        for(Field f:field){
//            System.out.println(f);
//        }
//        Method[] me = c1.getDeclaredMethods();//getMethods();
//        
//        for(Method n:me){
//            System.out.println(n);
//            Parameter[] p = n.getParameters();
//             for(Parameter pa:p){
//                 System.out.println(pa);
//             }
//        }
        try {

            Runtime run = Runtime.getRuntime();
            run.exec("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
        } catch (IOException e) {
            e.printStackTrace();
        }
        //        
        //        
        //        System.out.print("Class represented by c1: ");         
        //        // toString method on c1 
        //        System.out.println(c1.toString()); 
        //          
        ////        System.out.print("Class represented by c2: ");          
        ////        // toString method on c2 
        ////        System.out.println(c1.toString()); 
        ////          
        ////        System.out.print("Class represented by c3: " );          
        ////        // toString method on c3 
        ////        System.out.println(c1.toString()); 
        //        
        //        System.out.println("classes: "+c1.getClasses()); 
        //        System.out.println("Fields: " +c1.getFields()); 
        //        System.out.println("Interfaces:" + c1.getInterfaces()); 
        //        
        //        
        //        //---------------------------
        //        ClassClass objcl = new ClassClass();
        //        System.out.println("classes: "+objcl.getClass());
        z        
    }
}
//public class TestClass 
//{
//    public static void main(String[] args) {
//    ClassClass obj = new ClassClass();
//    System.out.println("Class is: " + obj.getClass());
//    }
//}

