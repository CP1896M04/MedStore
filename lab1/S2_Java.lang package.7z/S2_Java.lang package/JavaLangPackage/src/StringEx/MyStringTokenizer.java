/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StringEx;

import java.util.StringTokenizer;

/**
 *
 * @author theanh
 */
public class MyStringTokenizer {
    public static void main(String a[]){
          String msg = "This program gives, sample code for, String Tokenizer";
          StringTokenizer st = new StringTokenizer(msg,",", true);
          while(st.hasMoreTokens()){
                      System.out.println(st.nextToken());
          }
     }
}
